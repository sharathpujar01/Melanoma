from keras.models import Sequential
from keras.layers import Convolution2D
from keras.layers import MaxPooling2D
from keras.layers import Flatten
from keras.layers import Dense
import matplotlib.pyplot as plt

#Flow of Data
classifier=Sequential()

classifier.add(Convolution2D(32,32,3,input_shape=(128,128,3),activation='relu'))
	classifier.add(MaxPooling2D(pool_size=(2,2)))


classifier.add(Convolution2D(32, 3, 3, activation = 'relu'))
	classifier.add(MaxPooling2D(pool_size = (2, 2)))

classifier.add(Convolution2D(32, 3, 3, activation = 'relu'))
	classifier.add(MaxPooling2D(pool_size = (2, 2)))


# Step 3 - Flattening
	classifier.add(Flatten())

# Step 4 - Full connection
classifier.add(Dense(output_dim = 128, activation = 'relu'))
classifier.add(Dense(output_dim = 128, activation = 'relu'))
classifier.add(Dense(output_dim = 128, activation = 'relu'))
classifier.add(Dense(output_dim = 1, activation = 'sigmoid'))


#optimizer


classifier.compile(optimizer='adam',loss='binary_crossentropy',metrics=['accuracy'])

#image preprocessing


from keras.preprocessing.image import ImageDataGenerator

train_datagen=ImageDataGenerator(rescale=1./255,
                                 shear_range=0.2,
                                 zoom_range=0.2,
                                 horizontal_flip=True)
test_datagen=ImageDataGenerator(rescale=1./255)


#using google drive you can upload your dataset
'''from google.colab import drive
drive.mount('/content/drive')


training_set = train_datagen.flow_from_directory('/content/drive/My Drive/Training',
                                                 target_size = (64, 64),
                                                 batch_size = 15,
                                                 class_mode = 'binary')


test_set = test_datagen.flow_from_directory('/content/drive/My Drive/Test',
                                            target_size = (64, 64),
                                            batch_size = 15,
                                            class_mode = 'binary')'''








#using localdrive you can upload your dataset



training_set=train_datagen.flow_from_directory('D:/Dataset_tt/Training',
                                                target_size=(128,128)
                                                ,batch_size=40,
                                                class_mode='binary')

test_set=test_datagen.flow_from_directory('D:/Dataset_tt/Test',
                                                target_size=(128,128)
                                                ,batch_size=40,
                                                class_mode='binary')


history=classifier.fit_generator(training_set,
                         samples_per_epoch=3200,
                         nb_epoch=50,
                         validation_data=test_set,
                         nb_val_samples=800)

plt.figure(figsize=[8,6])
plt.plot(history.history['loss'],'r',linewidth=3.0)
plt.plot(history.history['val_loss'],'b',linewidth=3.0)
plt.legend(['Training loss', 'Validation Loss'],fontsize=18)
plt.xlabel('Epochs ',fontsize=16)
plt.ylabel('Loss',fontsize=16)
plt.title('Loss Curves',fontsize=16)


plt.figure(figsize=[8,6])
plt.plot(history.history['acc'],'r',linewidth=3.0)
plt.plot(history.history['val_acc'],'b',linewidth=3.0)
plt.legend(['Training Accuracy', 'Validation Accuracy'],fontsize=18)
plt.xlabel('Epochs ',fontsize=16)
plt.ylabel('Accuracy',fontsize=16)
plt.title('Accuracy Curves',fontsize=16)
